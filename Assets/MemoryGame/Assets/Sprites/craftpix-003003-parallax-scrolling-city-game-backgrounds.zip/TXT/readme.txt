Arial Narrow 7
https://www.dafont.com/arial-narrow-7.font